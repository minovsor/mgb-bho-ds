function val = testa_area_aceitavel(a_diff_perc,area_to_test)
%TESTA_AREA_ACEITAVEL Summary of this function goes here
 
% Tabela de diferen�a de area aceitavel (%)
nTable_dArea = 10;
area_min = NaN(nTable_dArea,1); area_max = NaN(nTable_dArea,1); d_area_acceptable = NaN(nTable_dArea,1);

%Defini��o da tabela 
area_min(1)=0; area_max(1)=1500; d_area_acceptable(1) = 30;
area_min(2)=1500; area_max(2)=3000; d_area_acceptable(2) = 25;
area_min(3)=3000; area_max(3)=5000; d_area_acceptable(3) = 20;
area_min(4)=5000; area_max(4)=10000; d_area_acceptable(4) = 15;
area_min(5)=10000; area_max(5)=20000; d_area_acceptable(5) = 10;
area_min(6)=20000; area_max(6)=50000; d_area_acceptable(6) = 7;
area_min(7)=50000; area_max(7)=200000; d_area_acceptable(7) = 5;
area_min(8)=200000; area_max(8)=500000; d_area_acceptable(8) = 3;
area_min(9)=500000; area_max(9)=1000000; d_area_acceptable(9) = 2;
area_min(10)=1000000; area_max(10)=6000000; d_area_acceptable(10) = 1.5;

val=0;
for j=1:nTable_dArea
    if (abs(a_diff_perc) < d_area_acceptable(j) && area_to_test >= area_min(j) && area_to_test < area_max(j))            
                %Marca o ponto como a ser resolvido com estrat�gio do raio
                val=1;
                break;
    end
end

