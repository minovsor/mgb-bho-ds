%Fun��o que testa a conectividade na medida que vai descendo o rio
function [cotrecho_jus, pos_table] = busca_conectividade(minimonts_otto,minijus,cotrecho_table,nutrjus_table,ottobac_table, maxIterations)

  %Assume a primeira
   next_down = minijus;

  % Vai descendo o rio para tentar encontrar uma BHO  que atenda o crit�rio de conectividade 
   for z = 1:maxIterations+1
    
       % Busca cotrecho que corresponde a mini selecionada
        yy=find(cotrecho_table==next_down);    
        
        % trecho fora do dom�nio do MGB
        if isempty(yy) == 1
            break;
        end    
        
        % Pega a ottobacia da nova mini de jusante
        next_otto = ottobac_table(yy);
                
        %Checa a conectividade via ottocodifica��o
        MiniFound = ottobacia_a_jusante(minimonts_otto,next_otto);
       
        %Se n�o encontrar nenhum trecho sem conectividade
        if isempty(find(MiniFound==0,1))
           
            %Retorna a mini
            cotrecho_jus = next_down; 
            %Retorna a posi��o na tabela
            pos_table = yy;
            %nIteracoes = z-1;
            return 
        end
       
        %Segue para o trecho de jusante
        next_down = nutrjus_table(yy);
   end
   
   %Se chegar ate aqui � por que n�o encontrou
   cotrecho_jus = NaN;
   pos_table = NaN;
   %nIteracoes = maxIterations;
   return
   
end

