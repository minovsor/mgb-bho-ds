%% Codigo para identificar trechos BHO que correspondem às minis (BHO level 1)
%
% Versão inicial: V. A. Siqueira e J.P.F.L. Breda
%
% Updates
% J.P. Breda 03/04/2020
% V.A. Siqueira 15/04/2020
% J.P. Breda 11/05/2020
% V.A. Siqueira 13/05/2020
% J.P. Breda 27/05/2020

%% Etapas anteriores

% Caixa de ferramentas QGIS >
% "Geometria de vetor" para converter de linha para ponto central>
% Calcula ponto de superfície (encontra o vértice médio de cada trecho de rio) >
% Calcula para MGB e BHO5k >
% SIRGAS 2000 para WGS 1984
% Intersect minibacias MGB com centros de trecho BHO5k


% ms: octave packages
pkg load io
%pkg load mapping


clear
clc
close all

%% Preparacao dos dados

a=importdata('mini.gtp',' ',1);
mini=a.data;

%% Número total de minibacias
nMini=length(mini);

%% Intervalos de tempo;
NT=7305;

% Threshold de area em km², que separa os algoritmos de compatibilização (canal principal x canal não-principal)
% Reduzi um pouco o threshold para evitar minibacias de cabeceira sem nenhum trecho
Area_threshold = 800;

%% Lê shape de pontos das redes de Drenagem

% Lê shape BHO5k (trechos convertidos para pontos) com as variáveis necessárias
#sBHO = shaperead('BHO5k_points_mini_intersect_2.shp','Attributes',{'cotrecho','cobacia','nunivotto','nutrjus','noorigem','nodestino','nuareacont','nuareamont','Mini','AreaM__km2'});

%ms: le csv no octave
sBHO = csvread('tabela_vs.csv');
sBHO = sBHO(2:end,:);

%% Converte struct para cell
sBHO_cell = struct2cell(sBHO)';

% Ajusta as variáveis do MGB
MGB_lat = mini(:,4);
MGB_lon = mini(:,3);
MGB_mini = 1:nMini;
MGB_area = mini(:,6);
MGB_areaMont = mini(:,7);
MGB_minijus = mini(:,12);
MGB_ordem=mini(:,13);

% Ajusta as variaveis do BHO
BHO_lat = cell2mat(sBHO_cell(:,3));
BHO_lon = cell2mat(sBHO_cell(:,2));
BHO_cotrecho = cell2mat(sBHO_cell(:,4));

BHO_cobacia = zeros(length(BHO_cotrecho),1);
for i = 1:length(BHO_cotrecho)
    BHO_cobacia(i)=eval(cell2mat(sBHO_cell(i,5)));
end

BHO_nunivotto = cell2mat(sBHO_cell(:,6));
BHO_nutrjus = cell2mat(sBHO_cell(:,7));
BHO_noorigem = cell2mat(sBHO_cell(:,8));
BHO_nodestino = cell2mat(sBHO_cell(:,9));
BHO_area = cell2mat(sBHO_cell(:,10));
BHO_aream = cell2mat(sBHO_cell(:,11));
BHO_mini = cell2mat(sBHO_cell(:,12));
BHO_areamgb = cell2mat(sBHO_cell(:,13));

clear sBHO_cell
MGB_mini=MGB_mini';

%% Filtrar para pegar o rio principal

d=find(BHO_aream>=Area_threshold);

BHO_area_filt=BHO_area(d);
BHO_aream_filt=BHO_aream(d);
BHO_areamgb_filt=BHO_areamgb(d);
BHO_cobacia_filt=BHO_cobacia(d);
BHO_cotrecho_filt=BHO_cotrecho(d);
BHO_lat_filt=BHO_lat(d);
BHO_lon_filt=BHO_lon(d);
BHO_mini_filt=BHO_mini(d);
BHO_nunivotto_filt=BHO_nunivotto(d);
BHO_nutrjus_filt=BHO_nutrjus(d);


%% achar os candidatos dos trechos do rio

cand=zeros(length(BHO_area_filt),1);
% colunas: 1 - cotrecho, 2 - diferenca de area, 3 - posicao no vetor
cand2=zeros(nMini,3);
cand2_otto=NaN(nMini,1);

%Define área limite para checar trechos na mini de jusante
Area_limite_minijus = 10000;

% flag que indica se o ponto estah dentro ou fora da minibacia
flag=zeros(nMini,1);

'Primeira rodada'
for i=1:nMini

    % Encontra se tem trechos da BHO na minibacia
    d=find(BHO_mini_filt==i);

    if isempty(d)==1 && MGB_areaMont(i) < Area_limite_minijus
        % Se não tem e é uma mini de cabeceira, identifica os pontos na mini de jusante
        d=find(BHO_mini_filt==MGB_minijus(i));
        if isempty(d)==1
            %Se não identifica nada, segue para a próxima mini
            continue
        end

        %Testa os pontos na mini de jusante
        % diferenca entre areas de drenagem da BHO com o MGB
        diff=abs(BHO_aream_filt(d)-MGB_areaMont(i));

        %Seleciona o ponto com a menor diferença de área de drenagem
        [x,c]=min(diff);
        cand2(i,1)=BHO_cotrecho_filt(d(c)); % 1 - cotrecho
        cand2(i,2)=x;  % 2 - diferenca de area
        cand2(i,3)=d(c); % 3 - posicao no vetor
        cand(d(c))=i; % minibacia

        %Armazena o codigo Otto
        cand2_otto(i)=BHO_cobacia_filt(d(c));

        %Segue para a próxima mini
        continue

    else

        %Se for area menor do que limiar maximo para identificar trechos a jusante
        %E tiver identificado trechos BHO dentro da mini
        if isempty(d)==0 && MGB_areaMont(i) < Area_limite_minijus

            % seleciona também os trechos da BHO da mini jusante
            d2=find(BHO_mini_filt==MGB_minijus(i));

            %Se encontrar pontos na mini de jusante
            if isempty(d2)==0

                %Primeiramente exclui os pontos da mini de jusante que não tiverem conectividade com a BHO de montante
                %Seleciona o codigo otto dos candidatos na mini de jusante
                cobacias_jus=BHO_cobacia_filt(d2);

                exclude_BHO=zeros(length(d2)+length(d),1);

                %Para cada BHO na mini de jusante, testa se está a jusante de algum dos trechos na mini mont
                for j=1:length(d2)

                    otto_test=ottobacia_a_jusante(BHO_cobacia_filt(d),cobacias_jus(j));

                     %Se há alguma conectividade, não exclui a BHO de jusante
                    if ~isempty(find(otto_test==1,1))
                        exclude_BHO(j)=false;
                    else
                        %caso contrário, exclui a BHO de jusante
                        exclude_BHO(j)=true;
                    end
                end

                % junta os trechos BHO na mini de jusante com as de montante
                d3=[d2;d];

                %Acha a menor diferença absoluta dentre todos os candidatos
                diff=abs(BHO_aream_filt(d3)-MGB_areaMont(i));
                %Coloca uma diferença de área infinita para os pontos sem conectividade
                exclude_BHO=logical(exclude_BHO);
                diff(exclude_BHO)=99999999999999;
            else
                %Se não encontrar, fica só com os pontos de montante;
                d3 = d;
                %Acha a menor diferença absoluta dentre todos os candidatos
                diff=abs(BHO_aream_filt(d3)-MGB_areaMont(i));
            end

            % pega o que der menor diferença
            [x,c]=min(diff);
            cand2(i,1)=BHO_cotrecho_filt(d3(c));
            cand2(i,2)=x;
            cand2(i,3)=d3(c);
            cand(d3(c))=i;

            %Armazena o codigo Otto
            cand2_otto(i)=BHO_cobacia_filt(d3(c));

            if BHO_mini_filt(d3(c))==i
                flag(i)=1;
            end

        elseif isempty(d)==0 && MGB_areaMont(i) > Area_limite_minijus

         %Nesse caso , área é maior que o limiar maximo para identificar trechos a jusante
         %Acha a menor diferença absoluta dentre todos os candidatos
         diff=abs(BHO_aream_filt(d)-MGB_areaMont(i));

         % pega o que der menor diferença
         [x,c]=min(diff);
         cand2(i,1)=BHO_cotrecho_filt(d(c));
         cand2(i,2)=x;
         cand2(i,3)=d(c);
         cand(d(c))=i;
         flag(i)=1;

         %Armazena o codigo Otto
         cand2_otto(i)=BHO_cobacia_filt(d(c));

        elseif isempty(d)==1 && MGB_areaMont(i) > Area_limite_minijus
            %Para áreas superiores ao limite e que não achou pontos
            %Não faz nada, segue para próxima mini
            continue

        end
    end
    i
end


%ms: grava resultado parcial
round = 1
fil_round1 = tabela_candidatos(round,nMini,cand2,BHO_cotrecho_filt,BHO_cobacia_filt,flag)




%% 2a rodada #VAS
% Analisa minibacias que recebem mais de um afluente
% Checa se os trechos BHO dos afluentes estão convergindo para o BHO da minibacia receptora
for i=1:nMini

    xx = find(MGB_minijus==i);

    %Somente se a bacia tem mais de um afluente
    if length(xx) > 1

        %Seleciona os códigos otto das BHO de minis afluentes
        cand_MiniMont_otto=cand2_otto(xx,1);
        %Seleciona o código otto e o cotrecho da BHO da mini que recebe
        cand_MiniJus_otto=cand2_otto(i,1);
        cand_MiniJus=cand2(i,1);

        %Somente resolve se há um candidato BHO para mini de jusante
        if cand_MiniJus_otto > 0

        %Testa a conectividade dos trechos de montante usando a codificação de Otto
        test_jus_conectiv = ottobacia_a_jusante(cand_MiniMont_otto,cand_MiniJus_otto);

        %Identifica se há trechos sem conectividade com o de jusante
        no_jus_conectiv = find(test_jus_conectiv==0);
        nSemConectiv = length(no_jus_conectiv);

        %Se o trecho de jusante for igual a algum de montante, ignora; passa para o próximo ponto
        jus_mont = find(test_jus_conectiv==-1);
        if isempty(jus_mont) == 1

            %(máx 5 descidas de rio)
            maxIter = 5;

             %Se há um BHO afluente sem conectividade com o de jusante
            if nSemConectiv > 0

                %Identifica a nova BHO de jusante
                [new_cand_MiniJus, pos_table] = busca_conectividade(cand_MiniMont_otto(no_jus_conectiv),cand_MiniJus,...
                                                            BHO_cotrecho_filt,BHO_nutrjus_filt,BHO_cobacia_filt, maxIter);

                %Atualiza informações caso encontrou uma nova mini
                if isnan(new_cand_MiniJus)==0
                    %Atualiza informações
                    cand2(i,1)=new_cand_MiniJus;
                    cand2(i,3)=pos_table;
                    %Atualiza diferença absoluta de área
                    cand2(i,2)=abs(BHO_aream_filt(pos_table)-MGB_areaMont(i));

                    %Atualiza informaçõe na tabela de BHO
                    yy=find(cand==i);
                     % desconecta a minibacia do trecho anterior
                    cand(yy)=0;
                    %Conecta a minibacia ao novo trecho
                    cand(pos_table)=i;

                end
            end
         end
       end
    end
   i
end

clear cand_MiniJus cand_MiniJus_otto cand_MiniMont_otto


%ms: grava resultado parcial
round = 2
fil_round2 = tabela_candidatos(round,nMini,cand2,BHO_cotrecho_filt,BHO_cobacia_filt,flag)



%% 3a rodada #JPLFB

'Terceira rodada'
erro_p=cand2(:,2)./MGB_areaMont*100;

% setando para 0 para poder refazer (limpando mbs com mto erro)

% digo que não eh candidato aqueles com erros altos ou em mb repetidas.
% do jeito q o cod estah escrito, a bho pode ser candidata de duas
% minibacias

% o loop é feito invertido, para zerar primeiro as de jusante
for i=nMini:-1:1
    % se jah nao tiver candidato, continua
    if cand2(i,1)==0
        continue
    end

    % usar o teste de area aceitavel
    val=testa_area_aceitavel(erro_p(i),MGB_areaMont(i));
    if val==0
        cand2(i,:)=0;
        cand(cand==i)=0;
        flag(i)=0;
        continue
    end

    % ver se tem duas minibacias apontando pra mesma bho
    g=find(cand2(:,1)==cand2(i,1));

    % se não tem duas minibacias pra mesma bho, continue
    if length(g)<=1
        % caso tivesse marcado com uma outra minibacia mais a jusante
        % que foi zerada agora, relaciona a bho a minibacia de montante
        if length(g)==1
            cand(cand2(i,3))=i; % cand2(x,3) indica a posicao no vetor BHO
        end
        continue
    % se tiver bho para mais de uma minibacia, a mais de jusante tem
    % predominancia
    elseif g(end)>i
        cand2(i,:)=0;
        flag(i)=0;
        % cand(cand==i)=0; % nao precisa pq provavelmente cand jah tah
        % associado a mais de jusante, ou seja
        % cand==i é vazio, pois cand=g(end)

    else % essa eh a minibacia mais de jusante, entao
        % caso tivesse marcado com uma outra minibacia mais a jusante
        % relaciona a bho a essa minibacia
        cand(cand2(i,3))=i; % cand2(x,3) indica a posicao no vetor BHO
    end
    i
end


%ms: grava resultado parcial
round = 3
fil_round3 = tabela_candidatos(round,nMini,cand2,BHO_cotrecho_filt,BHO_cobacia_filt,flag)

%ms:INICIO DO 4O ROUND



% criando topologia com o codigo da ottobacia
BHO_topo_filt=BHO_cobacia_filt./10.^(BHO_nunivotto_filt);

% retirando das opcoes os trechos que jah sao candidatos
BHO_mini_filt2=BHO_mini_filt;
BHO_mini_filt2(cand>0)=0;

% segunda rodada de fato considerando as minibacias vizinhas

% na segunda rodada nós vamos:
% 1: se a ordem for 1 ou nao tiver minibacia de montante com trechos bho,
% considerar a de jusante e pegar ponto não repetido;
% 2: se tiver pontos a montante e jusante, verificar a
% proximidade espacial (0.5o) e a topologia

for i=1:nMini

    % se jah tiver ponto relacionado, continua
    if cand2(i,1)>0
        continue
    end

    % condicao 1
    g=find(MGB_minijus==i);
    % se a ordem for 1 ou se as mini de montante nao tiver dados
    % ou se nao tiver minibacia de jusante
    if MGB_ordem(i)==1 || sum(cand2(g,1))==0 || MGB_minijus(i)==-1
        % encontrar os pontos bho dentro da mb
         d=find(BHO_mini_filt2==i);
         % encontrar os pontos bho dentro da mb de jusante
         if MGB_minijus(i)>-1
             d2=find(BHO_mini_filt2==MGB_minijus(i));
             d=[d; d2];
         end

         % se nao tiver trecho bho em canto nenhum
         if isempty(d)
             continue
         end

         %Acha a menor diferença absoluta dentre todos os candidatos
         diff=abs(BHO_aream_filt(d)-MGB_areaMont(i));

         % pega o que der menor diferença
         [x,c]=min(diff);
         cand2(i,1)=BHO_cotrecho_filt(d(c));
         cand2(i,2)=x;
         cand2(i,3)=d(c);
         cand(d(c))=i;
         if BHO_mini_filt(d(c))==i
             flag(i)=1;
         end

	% condicao 2
    elseif cand2(MGB_minijus(i),1)>0
        xx=cand2(g,3); % posicao do vetor das BHO das minis montante
        xx=xx(xx>0); % selecionando apenas os trechos com candidatos
        [t1,it1]=min(BHO_topo_filt(xx)); % menor topologia (mais jusante) entre minibacias de montante % MOD 28/07
        t3=BHO_cobacia_filt(xx); % topologia com ottocodificacao completa % ADD 28/07
        t3=t3(it1); % menor topologia dentre as minis de montante % ADD 28/07
        xx=cand2(MGB_minijus(i),3); % posicao da mini de jusante no vetor BHO
        t2=BHO_topo_filt(xx); % topologia da minibacia de jusante

        % candidatos com base na topologia
        d=find(BHO_topo_filt>t2 & BHO_topo_filt<t1);

        % se nao tiver trecho bho em canto nenhum
        if isempty(d)
            continue
        else
            lat=MGB_lat(i);
            lon=MGB_lon(i);
            k2=[];
            for k=1:length(d)
                dist=sqrt((BHO_lat_filt(d(k))-lat).^2+...
                    (BHO_lon_filt(d(k))-lon).^2);
                jus_true = ottobacia_a_jusante(t3,BHO_cobacia_filt(d(k))); % ADD 28/07
                if dist>0.5 || cand(d(k))>0 || jus_true~=1 % MOD 28/07
                    k2=[k2 k];
                end
            end
            d(k2)=[];
            if isempty(d)
                continue
            end
        end
        %Acha a menor diferença absoluta dentre todos os candidatos
        diff=abs(BHO_aream_filt(d)-MGB_areaMont(i));

        % pega o que der menor diferença
        [x,c]=min(diff);
        cand2(i,1)=BHO_cotrecho_filt(d(c));
        cand2(i,2)=x;
        cand2(i,3)=d(c);
        cand(d(c))=i;
        if BHO_mini_filt(d(c))==i
            flag(i)=1;
        end
    end

end


%ms: grava resultado parcial
round = 4
fil_round4 = tabela_candidatos(round,nMini,cand2,BHO_cotrecho_filt,BHO_cobacia_filt,flag)


%Corrige a area do MGB associada aos pontos BHO, dado que alguns foram selecionados a jusante da minibacia
BHO_areamgb_corrected=zeros(length(BHO_area_filt),1);

for i= 1:length(BHO_area_filt)
   if cand(i) > 0
      BHO_areamgb_corrected(i) = MGB_areaMont(cand(i));
   end
   i
end

%Calcula diferença percentual de area
area_diff_perc = 100*(BHO_aream_filt - BHO_areamgb_corrected)./ BHO_areamgb_corrected;
%Troca valores infinitos para NaN;
area_diff_perc(isinf(area_diff_perc)==1)=NaN;

% pontos nivel 2 com flag se eh candidato ou nao
candidates2=[BHO_lat_filt BHO_lon_filt cand];

%Cria tabela de correspondencia mini x BHO
candidates=NaN(nMini,8);
for i=1:nMini

       candidates(i,1)=i;

       %Preenche informações para minibacias em que correspondencia foi encontrada
    if cand2(i,1)>0
        xx=find(BHO_cotrecho_filt==cand2(i));
        candidates(i,2)=BHO_cotrecho_filt(xx);
        candidates(i,3)=BHO_cobacia_filt(xx);
        candidates(i,4)=BHO_aream_filt(xx);
        candidates(i,5)=BHO_areamgb_corrected(xx);
        candidates(i,6)=area_diff_perc(xx);
        candidates(i,7)=BHO_lat_filt(xx);
        candidates(i,8)=BHO_lon_filt(xx);
    end
    i
end


%% Escreve os resultados
candidates=[candidates flag];
%candidates(isnan(candidates))=-1;
cabecalho='      Mini    cotrecho     codigo_otto   AreaM_BHO   AreaM_MGB    Diff(%)   Lat      Lon   Flag_mini_in';
fid=fopen('candidates.txt','w+');
fprintf(fid,'%70s \n',cabecalho);
fprintf(fid,'%10i %10i %15i %11.1f %11.1f %10.2f %8.3f %8.3f %4i \n',candidates');
fclose(fid)

% fid=fopen('candidates2.txt','w+');
% fprintf(fid,'%20s \n','Lat	Lon	Mini');
% fprintf(fid,'%8.3f %8.3f %10i \n',candidates2');
% fclose(fid)