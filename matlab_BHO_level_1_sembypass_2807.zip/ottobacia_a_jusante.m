%Fun��o para identificar se o trecho BHO esta a jusante de qualquer outro
%Identifica��o via codifica��o de Otto

function jus_true = ottobacia_a_jusante(codigo_montante,codigo_jusante)

% Resultado:
% 1 - Codigo de jusante est� a jusante
% 0 - Codigo de jusante n�o est� a jusante
% -1 - Codigo de jusante = de montante
% NaN - N�o h� c�digo informado

jus_true=NaN(length(codigo_montante),1);

for z =1: length(codigo_montante)
 
  % Retorna NaN se n�o h� codigo
  if isnan(codigo_montante(z))==1
      jus_true(z) = NaN;
      return
  end
 
  %Trecho de montante = jusante, assume -1;
  if codigo_montante(z)==codigo_jusante
      jus_true(z) = -1;
      return
  end
  
  codigo1=num2str(codigo_montante(z));
  codigo2=num2str(codigo_jusante);

    % trick para acelerar um pouco: se 1o algarismo � != j� ignora
    if codigo2(1) ~= codigo1(1)
       jus_true(z) = 0;
       return
    end
                
    % (i) parte a esquerda em comum,
    nalgarismo_jus = length(codigo2);
    nalgarismo_mon = length(codigo1);
    
    %Pega o n�mero m�nimo de algarismos entre os dois casos
    nalgarismo = min(nalgarismo_jus,nalgarismo_mon);
    
    for n=1:nalgarismo     
        if (codigo2(1:n)==codigo1(1:n))
            sleft = codigo2(1:n);
            nleft = length(sleft);        
        end
    end
    
    algarismo_1 = str2double(codigo1(nleft+1));
    algarismo_2 = str2double(codigo2(nleft+1));
    
    %Checa o pr�ximo n�mero para verificar se � impar ou par
    if mod(algarismo_2,2) == 0
        par2 = 1;
    else
        par2 = 0;
    end
    
    %Testa a condi��o de jusante 
    if (par2 == 0) && (algarismo_1 > algarismo_2)
        %Se for �mpar e o outro for qualquer n�mero maior, ent�o est� a jusante
        jus_true(z) = 1;
    else 
        jus_true(z) = 0;
    end
end
    
end 